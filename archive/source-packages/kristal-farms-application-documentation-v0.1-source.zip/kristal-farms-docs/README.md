# Kristal Farms

> Evidence-driven geospatial system for northern energy infrastructure, flexible compute, telecom corridors, and future scenario analysis.

## Why this repository exists

Kristal Farms is designed to begin as a high-impact public technical showcase and mature into a professional geospatial decision-support platform without replacing its underlying architecture.

Kristal Farms has three product surfaces built on one data model:

1. **Showcase** — narrative, visually polished public experience.
2. **Explorer** — professional map, evidence, filters, timeline, metadata, and exports.
3. **Scenario Studio** — future energy/compute scenario modeling and comparison.

## Architecture at a glance

```mermaid
flowchart TD
  Users[Public + Professional users] --> Web[React / TypeScript / Next.js]
  Web --> Map[MapLibre GL JS]
  Web --> Viz[deck.gl]
  Web --> API[Kristal Farms API / FastAPI]
  Web --> OGC[OGC API / pygeoapi]
  Web --> Tiles[Vector tiles / Martin]
  API --> DB[(PostgreSQL / PostGIS)]
  OGC --> DB
  Tiles --> DB
  DB --> QGIS[QGIS / GIS professionals]
  DB --> Publish[Publish pipeline]
  Publish --> PMT[PMTiles + COG + metadata]
  PMT --> CDN[Object storage / CDN]
```

## Non-negotiable domain rules

- Existing autonomous-grid planning margin is **not** compute hosting capacity.
- Community loads are priority loads; compute is the flexible/curtailable load.
- Multi-MW Kristal Farms concepts require their own generation and electrical architecture.
- External renewable projects are reference cases unless explicitly reclassified.
- Evidence may be valid without geometry.
- No site ranking is allowed while `ranking_allowed = false`.
- Public releases must never contain private data hidden only by UI controls.

See [Domain Rules](docs/domain/kristal-farms-principles.md).

## Documentation map

Start with:

- [Documentation index](docs/index.md)
- [System architecture](docs/architecture/overview.md)
- [Data model](docs/data/data-model.md)
- [Evidence model](docs/data/evidence-model.md)
- [Cartography](docs/frontend/cartography.md)
- [Layer catalog](docs/frontend/layer-catalog.md)
- [Scenario model](docs/scenarios/scenario-model.md)
- [Pass 8 migration](docs/data/pass8-migration.md)
- [AI development rules](AGENTS.md)
- [Architecture decisions](docs/adr/README.md)

## Repository status

This package documents the target repository architecture. It is intended to be copied into the implementation repository and evolved with code through Architecture Decision Records (ADRs), migrations, API contracts, and release notes.

## Proposed top-level implementation layout

```text
apps/web/                 Public Showcase + Explorer + Scenario UI
services/kristal-farms-api/     Domain API and scenario execution
services/ogc-api/         OGC API deployment/configuration
services/tiles/           Martin tile service configuration
packages/schemas/         Shared contracts / generated types
packages/catalog/         Layer catalog loader and validation
packages/map-style/       Kristal Farms cartographic style definitions
pipelines/                Ingest, transform, QA, publish
 database/                Migrations, SQL views, functions, seeds
contracts/                Machine-readable system contracts
docs/                     Human documentation
infra/                    Local/staging/production deployment
```

## Documentation site

The docs are configured for MkDocs. Run the documentation site from the repository root after installing the docs dependencies described in [Documentation workflow](docs/contributing/documentation.md).
