# Contributing

See [Development workflow](docs/contributing/development-workflow.md) and [Pull requests](docs/contributing/pull-requests.md).

Key rule: changes to data semantics, architecture, security boundaries, or public cartographic meaning require accompanying documentation and, when durable, an ADR.
