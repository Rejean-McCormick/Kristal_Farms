# Repository structure

Recommended implementation monorepo:

```text
.
├── apps/
│   └── web/
├── services/
│   ├── kristal-farms-api/
│   ├── ogc-api/
│   └── tiles/
├── packages/
│   ├── schemas/
│   ├── catalog/
│   ├── map-style/
│   ├── ui/
│   └── shared/
├── pipelines/
│   ├── ingest/
│   ├── transform/
│   ├── validate/
│   └── publish/
├── database/
│   ├── migrations/
│   ├── functions/
│   ├── views/
│   └── seeds/
├── contracts/
│   ├── api/
│   ├── layers/
│   ├── policy/
│   ├── releases/
│   └── schemas/
├── data/
│   └── fixtures/
├── infra/
├── docs/
└── .github/
```

The documentation bundle intentionally includes `contracts/` and `.github/` because these are part of the operational documentation contract, not merely prose.
